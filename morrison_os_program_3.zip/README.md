Mitchell Morrison \
OS Program 3

Important Notes:

* The names of the players must be a string (not an int)
* The resources must be integers
* To run the sample input file, it takes about 2 minutes